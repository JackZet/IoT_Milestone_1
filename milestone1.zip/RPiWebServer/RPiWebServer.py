from flask import Flask, render_template
import datetime
import RPi.GPIO as GPIO
import dht11
import time

GPIO.setwarnings(True)
GPIO.setmode(GPIO.BCM)

app = Flask(__name__)
@app.route("/")
def hello():
    
   
   
   temp, hum = temphum()

   now = datetime.datetime.now()
   timeString = now.strftime("%Y-%m-%d %H:%M")
   templateData = {
      'Temp' : temp,
      'Dist': distance(),
      'Humid': hum,
      }
   return render_template('index.html', **templateData)

def distance():
    TRIG = 23
    ECHO = 24

    print("Distance Measurement In Progress")

    GPIO.setup(TRIG,GPIO.OUT)
    GPIO.setup(ECHO,GPIO.IN)

    GPIO.setup(TRIG, GPIO.OUT)
    GPIO.setup(ECHO, GPIO.IN)

    GPIO.output(TRIG, False)
    print("Waiting For Sensor To Settle")
    time.sleep(2)

    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    while GPIO.input(ECHO)==0:
        pulse_start = time.time()

    while GPIO.input(ECHO)==1:
        pulse_end = time.time()
        
    pulse_duration = pulse_end - pulse_start

    distance = pulse_duration * 17150

    distance = round(distance, 2)

    print("Distance:", distance,"cm")
    return distance

def temphum():
    
    instance = dht11.DHT11(pin=12)

    result = instance.read()
    if result.is_valid():
        print("Last valid input: " + str(datetime.datetime.now()))
        print("Temperature: %-3.1f C" % result.temperature)
        print("Humidity: %-3.1f %%" % result.humidity)
        return result.temperature, result.humidity
    print("Cleanup")
    GPIO.cleanup()
    

if __name__ == "__main__":
    #REPLACE 0.0.0.0 (ifconfig -> wlan0: for at finde host) 
   app.run(host='0.0.0.0', port=5001, debug=True)
